package com.example.Restsqldemo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Studentservice {
@Autowired
StudentRepositry s;
public List<Student>getAllStudent(){
	return(List<Student>)s.findAll();
}
public Student getStudentById(String id) {
	return s.findById(id).orElse(null);
}
public Student createstudent(Student student) {
	return s.save(student);
}
public Student updatestudent(String id, Student student) {
	if(s.existsById(id)) {
		student.setSid(id);
		return s.save(student);
	}
	return null;
}
public void deletestudent(String id) {
	s.deleteById(id);
}
}
