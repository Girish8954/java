package com.example.Restsqldemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestsqldemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestsqldemoApplication.class, args);
	}

}
