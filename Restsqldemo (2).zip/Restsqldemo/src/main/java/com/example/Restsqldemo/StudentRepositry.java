package com.example.Restsqldemo;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface StudentRepositry extends CrudRepository<Student,String>{

}
